package posttest2;

import java.util.ArrayList;
import java.util.Scanner;

public class artis {
    private final String kodeF = "F";
    private long noKodeF;
    protected String namaArtis, judulLagu, jamTampil;
    public int urutTampil;


    artis(String namaArtis, String judulLagu, String jamTampil, int urutTampil, long noKode){
        this.namaArtis = namaArtis;
        this.judulLagu = judulLagu;
        this.urutTampil = urutTampil;
        this.jamTampil = jamTampil;
        this.noKodeF = noKode;
    }

    artis() {
        //UNTUK MENGATASI EROR DI MAIN
    }


    public String getKodeF() {
        return kodeF;
    }

    public long getNoKodeF() {
        return noKodeF;
    }

    public String getNamaArtis() {
        return namaArtis;
    }

    public String getJudulLagu() {
        return judulLagu;
    }

    public String getJamTampil() {
        return jamTampil;
    }

    public int getUrutTampil() {
        return urutTampil;
    }

    public artis getF() {
        return F;
    }

    public ArrayList<artis> getFList() {
        return FList;
    }

    public Scanner getInp() {
        return inp;
    }

    public Scanner getInputInt() {
        return inputInt;
    }

    artis F;
    ArrayList<artis> FList = new ArrayList<>();
    Scanner inp = new Scanner(System.in);
    Scanner inputInt = new Scanner(System.in);
    protected void tambahData (){
        boolean ulang=true;
        System.out.println("\nMenambahkan Data\n");
        System.out.print("Nama Artis : ");
        namaArtis = inp.nextLine();
        System.out.print("Judul Lagu : ");
        judulLagu = inp.nextLine();
        System.out.print("Jam Tampil : ");
        jamTampil = inp.nextLine();
        while(ulang){
            System.out.print("Urutan Tampil : ");
            String strJam=inp.nextLine();
            if (strJam.equals("0")){
                System.err.println("Data Ini Tidak Boleh Bernilai 0");
            }
            else{
                try{
                    urutTampil = (Integer.parseInt(strJam));
                    noKodeF++;
                    System.out.println("Nomor Data : " + kodeF + noKodeF);
                    F = new artis(namaArtis, judulLagu, jamTampil, urutTampil, noKodeF); // OBJEK ke - 1
                    FList.add(F);
                    System.out.println("\n>> Tambah Data Berhasil <<");
                    ulang=false;
                }catch(Exception e){
                    System.err.println("Data Yang anda masukkan tidak sesuai");
                }
            }
        }
    }
    protected void tampilData(){
        System.out.println("\nMenampilkan Data\n");
        for (int i=0; i<FList.size(); i++){
            System.out.println("No. : " + kodeF + FList.get(i).getNoKodeF());
            System.out.println("Nama Artis : " + FList.get(i).getNamaArtis());
            System.out.println("Judul Lagu : " + FList.get(i).getJudulLagu());
            System.out.println("Urutan Tampil : " + FList.get(i).getUrutTampil());
            System.out.println("Jam Tampil : " + FList.get(i).getJamTampil());
            System.out.println(" ");
        }
    }
    public void hapusData() {
        System.out.println("\nMenghapus Data\n");
        for (int i=0; i<FList.size(); i++){
            System.out.println("No : " + kodeF +
                    FList.get(i).getNoKodeF());
            System.out.println("Nama Artis : " + FList.get(i).getNamaArtis());
            System.out.println(" ");
            // System.out.println("Index ["+i+"] Nama Produk : " + arrMakan.get(i).nama);
        }
        int hapus;
        System.out.print("\nInput Nomor Data untuk Hapus : ");
        hapus = inputInt.nextInt();
        hapus--;
        FList.remove(hapus);
        System.out.println("\n>> Hapus Data Berhasil <<\n");
    }
    public ArrayList<artis> ubahData(ArrayList<artis> Flist) {
        int ubah;
        System.out.println("\nMengubah Data\n");
        for (int i=0; i<FList.size(); i++){
            System.out.println("Nomor Data : " + kodeF +
                    FList.get(i).getNoKodeF());
            System.out.println("Nama Artis : " + FList.get(i).getNamaArtis());
            System.out.println(" ");
        }
        if (FList.size() == 1){
            ubah = 0;
        } else {
            System.out.print("\nInput Nomor Data untuk Edit  : ");
            ubah = inputInt.nextInt();
            ubah--;
        }
        System.out.print("\nNama Artis : ");
        FList.get(ubah).namaArtis = (inp.nextLine());
        System.out.print("Judul Lagu : ");
        FList.get(ubah).judulLagu = inp.nextLine();
        System.out.print("Jam Tampil : ");
        FList.get(ubah).jamTampil = inp.nextLine();
        System.out.print("Urutan Tampil : ");
        FList.get(ubah).urutTampil = inputInt.nextInt();
        System.out.println("\n>> Edit Data Berhasil <<\n");

        return FList;
    }
}
